// Global cart array
let cart = [];

// Function to add a product to the cart
function addToCart(name, price) {
  let existingItem = cart.find((item) => item.name === name);

  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push({ name, price, quantity: 1 });
  }

  updateCartCount();
  displayCartItems();
  showNotification(`${name} added to cart!`);
}

// Function to update the cart count
function updateCartCount() {
  let totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  document.getElementById("cart-count").innerText = totalCount;
}

// Function to toggle the cart modal
function toggleCart() {
  let cartModal = document.getElementById("cart-modal");
  cartModal.style.display =
    cartModal.style.display === "block" ? "none" : "block";
  displayCartItems();
}

// Function to display cart items
function displayCartItems() {
  let cartItemsList = document.getElementById("cart-items");
  let cartTotal = document.getElementById("cart-total");

  cartItemsList.innerHTML = "";
  let totalAmount = 0;

  if (cart.length === 0) {
    cartItemsList.innerHTML = "<p>Your cart is empty.</p>";
    cartTotal.innerText = "0";
    return;
  }

  cart.forEach((item, index) => {
    let listItem = document.createElement("li");
    listItem.innerHTML = `
            <div class="cart-item">
                <span>${item.name}</span>
                <div class="cart-controls">
                    <button onclick="changeQuantity(${index}, -1)">➖</button>
                    <span>${item.quantity}</span>
                    <button onclick="changeQuantity(${index}, 1)">➕</button>
                    <button class="remove-btn" onclick="removeFromCart(${index})">❌</button>
                </div>
                <span class="price">₱${(
                  item.price * item.quantity
                ).toLocaleString()}</span>
            </div>
        `;
    cartItemsList.appendChild(listItem);
    totalAmount += item.price * item.quantity;
  });

  cartTotal.innerText = `₱${totalAmount.toLocaleString()}`;
}

// Function to change item quantity
function changeQuantity(index, change) {
  if (cart[index].quantity + change <= 0) {
    cart.splice(index, 1);
  } else {
    cart[index].quantity += change;
  }

  updateCartCount();
  displayCartItems();
}

// Function to remove an item from the cart
function removeFromCart(index) {
  cart.splice(index, 1);
  updateCartCount();
  displayCartItems();
}

// Function to handle checkout
function checkout() {
  if (cart.length === 0) {
    showNotification("Your cart is empty!", "error");
    return;
  }

  showNotification(
    `Purchase Successful! Total: ₱${cart
      .reduce((sum, item) => sum + item.price * item.quantity, 0)
      .toLocaleString()}`,
    "success"
  );

  cart = [];
  updateCartCount();
  toggleCart();
}

// Function to filter products based on search input
function searchProducts() {
  let query = document.getElementById("search").value.toLowerCase();
  let products = document.querySelectorAll(".product");

  products.forEach((product) => {
    let name = product.getAttribute("data-name").toLowerCase();
    product.style.display = name.includes(query) ? "inline-block" : "none";
  });
}

// Function to show notifications
function showNotification(message, type = "info") {
  let notification = document.createElement("div");
  notification.className = `notification ${type}`;
  notification.innerText = message;
  document.body.appendChild(notification);

  setTimeout(() => {
    notification.style.opacity = "0";
    setTimeout(() => notification.remove(), 300);
  }, 2000);
}
