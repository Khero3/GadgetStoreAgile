<?php
$host = "ITG-EQUIP1514";  // Change if needed
$user = "sa";       // Change for production
$pass = "pw";           // Change for production
$dbname = "MiniEcommerce";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
